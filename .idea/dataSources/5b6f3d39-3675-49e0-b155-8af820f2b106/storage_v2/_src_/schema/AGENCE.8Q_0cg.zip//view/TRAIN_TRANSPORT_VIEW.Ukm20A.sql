create view TRAIN_TRANSPORT_VIEW as
  SELECT t.ID,
         t.DEPART_DATE,
         t.ARRIVEE_DATE,
         t.NOMBRE_SIEGES_OCCUPES,
         t.NOMBRE_SIEGES_TOTAL,
         t.PRIX,
         tr.NOMBRE_WAGONS,
         tr.VOITURE_CAFETERIA,
         tr.TYPE_APPAREIL
  FROM "AGENCE"."TRANSPORT" t
         INNER JOIN "AGENCE"."TRAIN" tr ON t.ID = tr.TRANSPORT_ID
/

