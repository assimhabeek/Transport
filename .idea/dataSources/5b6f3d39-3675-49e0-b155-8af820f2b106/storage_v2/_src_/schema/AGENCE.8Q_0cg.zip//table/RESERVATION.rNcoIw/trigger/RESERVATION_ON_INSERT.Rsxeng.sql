create trigger RESERVATION_ON_INSERT
  before insert
  on RESERVATION
  for each row
  BEGIN
    SELECT reservation_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

