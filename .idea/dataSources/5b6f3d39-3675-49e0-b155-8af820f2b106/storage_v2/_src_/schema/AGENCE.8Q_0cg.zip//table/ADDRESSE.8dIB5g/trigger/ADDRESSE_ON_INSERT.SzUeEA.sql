create trigger ADDRESSE_ON_INSERT
  before insert
  on ADDRESSE
  for each row
  BEGIN
    SELECT addresse_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

