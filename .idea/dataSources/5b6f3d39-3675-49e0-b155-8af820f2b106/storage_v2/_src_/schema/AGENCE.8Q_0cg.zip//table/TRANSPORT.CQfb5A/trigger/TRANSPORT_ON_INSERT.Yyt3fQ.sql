create trigger TRANSPORT_ON_INSERT
  before insert
  on TRANSPORT
  for each row
  BEGIN
    SELECT transport_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

