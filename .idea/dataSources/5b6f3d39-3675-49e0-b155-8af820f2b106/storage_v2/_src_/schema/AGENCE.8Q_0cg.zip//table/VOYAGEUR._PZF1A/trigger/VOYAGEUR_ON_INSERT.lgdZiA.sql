create trigger VOYAGEUR_ON_INSERT
  before insert
  on VOYAGEUR
  for each row
  BEGIN
    SELECT voyageur_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

