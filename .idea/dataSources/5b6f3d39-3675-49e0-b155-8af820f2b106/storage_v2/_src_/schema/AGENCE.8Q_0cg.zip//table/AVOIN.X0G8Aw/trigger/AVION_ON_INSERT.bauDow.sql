create trigger AVION_ON_INSERT
  before insert
  on AVOIN
  for each row
  BEGIN
    SELECT avion_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

