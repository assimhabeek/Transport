create trigger FACTURE_ON_INSERT
  before insert
  on FACTURE
  for each row
  BEGIN
    SELECT facture_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

