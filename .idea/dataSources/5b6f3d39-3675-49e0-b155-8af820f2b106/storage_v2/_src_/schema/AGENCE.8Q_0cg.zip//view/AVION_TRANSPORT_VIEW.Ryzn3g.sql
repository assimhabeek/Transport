create view AVION_TRANSPORT_VIEW as
  SELECT t.ID,
         t.DEPART_DATE,
         t.ARRIVEE_DATE,
         t.NOMBRE_SIEGES_OCCUPES,
         t.NOMBRE_SIEGES_TOTAL,
         t.PRIX,
         a.COMPAGNIE,
         a.TYPE_APPAREIL
  FROM "AGENCE"."TRANSPORT" t
         INNER JOIN "AGENCE"."AVOIN" a ON t.ID = a.TRANSPORT_ID
/

