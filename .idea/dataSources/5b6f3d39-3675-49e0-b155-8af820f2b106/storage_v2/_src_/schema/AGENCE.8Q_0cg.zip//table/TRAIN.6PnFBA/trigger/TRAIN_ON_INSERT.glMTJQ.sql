create trigger TRAIN_ON_INSERT
  before insert
  on TRAIN
  for each row
  BEGIN
    SELECT train_sequence.nextval
        INTO :new.id FROM dual;
  END;
/

